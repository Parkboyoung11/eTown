<?php
/*adding sections for custom css options */
$wp_customize->add_section( 'education-base-design-custom-css-option', array(
    'priority'       => 60,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '',
    'title'          => __( 'Custom CSS', 'education-base' ),
    'panel'          => 'education-base-design-panel'
) );

/*custom-css*/
$wp_customize->add_setting( 'education_base_theme_options[education-base-custom-css]', array(
    'capability'		=> 'edit_theme_options',
    'default'			=> $defaults['education-base-custom-css'],
    'sanitize_callback' => 'wp_strip_all_tags'
) );
$wp_customize->add_control( 'education_base_theme_options[education-base-custom-css]', array(
    'label'		=> __( 'Custom CSS', 'education-base' ),
    'section'   => 'education-base-design-custom-css-option',
    'settings'  => 'education_base_theme_options[education-base-custom-css]',
    'type'	  	=> 'textarea',
    'priority'  => 10
) );