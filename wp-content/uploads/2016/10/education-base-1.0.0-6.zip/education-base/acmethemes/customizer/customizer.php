<?php
/**
 * Education Base Theme Customizer.
 *
 * @package Acme Themes
 * @subpackage Education Base
 */

/*
* file for customizer core functions
*/
require education_base_file_directory('acmethemes/customizer/customizer-core.php');
/*
* file for customizer sanitization functions
*/
require education_base_file_directory('acmethemes/customizer/sanitize-functions.php');

/**
 * Adding different options
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function education_base_customize_register( $wp_customize ) {

    $wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
    $wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';

    /*saved options*/
    $options  = education_base_get_theme_options();

    /*defaults options*/
    $defaults = education_base_get_default_theme_options();

    require education_base_file_directory('acmethemes/customizer/custom-controls.php');

    /*
     * file for feature panel of home page
     */
    require education_base_file_directory('acmethemes/customizer/feature-section/feature-panel.php');

    /*
    * file for header panel
    */
    require education_base_file_directory('acmethemes/customizer/header-options/header-panel.php');

    /*
    * file for customizer footer section
    */
    require education_base_file_directory('acmethemes/customizer/footer-options/footer-panel.php');

    /*
    * file for design/layout panel
    */
    require education_base_file_directory('acmethemes/customizer/design-options/design-panel.php');

    /*
     * file for options panel
     */
    require education_base_file_directory('acmethemes/customizer/options/options-panel.php');

    /*removing*/
    $wp_customize->remove_panel('header_image');
    $wp_customize->remove_control('header_textcolor');
}
add_action( 'customize_register', 'education_base_customize_register' );

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function education_base_customize_preview_js() {
    wp_enqueue_script( 'education-base-customizer', get_template_directory_uri() . '/acmethemes/core/js/customizer.js', array( 'customize-preview' ), '1.1.0', true );
}
add_action( 'customize_preview_init', 'education_base_customize_preview_js' );

/**
 * Theme Update Script
 *
 * For backward compatibility
 */
function education_base_update_check() {

    global $wp_version;
    // Return if wp version less than 4.5
    if ( version_compare( $wp_version, '4.5', '<' ) ) {
        return;
    }
    $education_base_saved_theme_options = education_base_get_theme_options();
    $site_logo = '';
    if( isset( $education_base_saved_theme_options['education-base-header-logo'] )){
        $site_logo = esc_url( $education_base_saved_theme_options['education-base-header-logo'] );
    }
    if ( empty( $site_logo ) ) {
        return;
    }
    /*converting url into attachment ID*/
    $logo = attachment_url_to_postid( $site_logo );
    if ( is_int( $logo ) ) {
        set_theme_mod( 'custom_logo', attachment_url_to_postid( $site_logo ) );
        $education_base_saved_theme_options['education-base-header-logo'] = '';
        set_theme_mod( 'education_base_theme_options', $education_base_saved_theme_options );
    }
}
add_action( 'after_setup_theme', 'education_base_update_check' );