<?php
/**
 * Excerpt length 70 return
 *
 * @since Education Base 1.0.0
 *
 * @param null
 * @return null
 *
 */
if ( !function_exists('education_base_alter_excerpt') ) :
    function education_base_alter_excerpt(){
        return 70;
    }
endif;

add_filter('excerpt_length', 'education_base_alter_excerpt');

/**
 * Add ... for more view
 *
 * @since Education Base 1.0.0
 *
 * @param null
 * @return null
 *
 */

if ( !function_exists('education_base_excerpt_more') ) :
    function education_base_excerpt_more($more) {
        return '...';
    }
endif;
add_filter('excerpt_more', 'education_base_excerpt_more');