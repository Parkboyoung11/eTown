<?php
/**
 * Education Base functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Acme Themes
 * @subpackage Education Base
 */

/**
 * Require init.
 */
$education_base_init_file_path = trailingslashit( get_template_directory() ).'acmethemes/init.php';
require $education_base_init_file_path;
