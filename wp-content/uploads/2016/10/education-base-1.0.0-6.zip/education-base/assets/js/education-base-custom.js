jQuery(document).ready(function($){
    function tick(){
        $('.news-notice-content .news-content:first').show( function () {
            $(this).appendTo($('.news-notice-content')).hide();
        });
    }
    setInterval(function(){ tick () }, 3000);

    function homeFullScreen() {

        var homeSection = $('#at-banner-slider');
        var windowHeight = $(window).outerHeight();

        if (homeSection.hasClass('home-fullscreen')) {

            $('.home-fullscreen').css('height', windowHeight);
        }
    }
    //make slider full width
    homeFullScreen();

    //window resize
    $(window).resize(function () {
        homeFullScreen();
    });

    $(window).load(function () {

        $('.acme-owl-carausel').show().owlCarousel({
            autoPlay : true,
            navigation : true, // Show next and prev buttons
            pagination : false, // Show next and prev buttons
            slideSpeed : 800,
            paginationSpeed : 600,
            singleItem:true,
            navigationText : ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
            addClassActive: true
        });

        /*parallax scolling*/
        $('a[href*="#"]').click(function(event){
            $('html, body').animate({
                scrollTop: $( $.attr(this, 'href') ).offset().top-$('.at-navbar').height()
            }, 1000);
            event.preventDefault();
        });
        /*bootstrap sroolpy*/
        $("body").scrollspy({target: ".navbar-fixed-top", offset: $('.at-navbar').height()+50 } );
    });

    function stickyMenu() {

        var scrollTop = $(window).scrollTop();
        var offset = 0;

        if ( scrollTop > offset ) {
            $('#navbar').addClass('navbar-fixed-top');
            $('.sm-up-container').show();
        }
        else {
            $('#navbar').removeClass('navbar-fixed-top');
            $('.sm-up-container').hide();
        }
    }
    //What happen on window scroll
    stickyMenu();
    $(window).on("scroll", function (e) {
        setTimeout(function () {
            stickyMenu();
        }, 300)
    });
});

/*animation with wow*/
wow = new WOW({
        boxClass: 'init-animate',
        animateClass: 'animated' // default
    }
);
wow.init();