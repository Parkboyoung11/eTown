jQuery(document).ready(function($){
    var at_window = $(window);
    /*custom ticker by @acmethemes*/
    var ticker = $('.news-notice-content'),
        ticker_first = ticker.children(':first');

    setInterval(function() {
        if ( !ticker_first.is(":hover") ){
            ticker_first.fadeOut(function() {
                ticker_first.appendTo(ticker);
                ticker_first = ticker.children(':first');
                ticker_first.fadeIn();
            });
        }
    },3000);

    function homeFullScreen() {

        var homeSection = $('#at-banner-slider');
        var windowHeight = at_window.outerHeight();

        if (homeSection.hasClass('home-fullscreen')) {

            $('.home-fullscreen').css('height', windowHeight);
        }
    }
    //make slider full width
    homeFullScreen();

    //window resize
    at_window.resize(function () {
        homeFullScreen();
    });

    at_window.on("load", function() {

        $('.acme-owl-carausel').show().owlCarousel({
            autoPlay : true,
            navigation : true, // Show next and prev buttons
            pagination : false, // Show next and prev buttons
            slideSpeed : 800,
            paginationSpeed : 600,
            singleItem:true,
            navigationText : ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
            addClassActive: true
        });

        /*parallax scolling*/
        $('a[href*="#"]').click(function(event){
            $('html, body').animate({
                scrollTop: $( $.attr(this, 'href') ).offset().top-$('.at-navbar').height()
            }, 1000);
            event.preventDefault();
        });
        /*bootstrap sroolpy*/
        $("body").scrollspy({target: ".navbar-fixed-top", offset: $('.at-navbar').height()+50 } );

        /*featured slider*/
        $('.acme-gallery').each(function(){
            var $masonry_boxes = $(this);
            var $container = $masonry_boxes.find('.fullwidth-row');
            $container.imagesLoaded( function(){
                $masonry_boxes.fadeIn( 'slow' );
                $container.masonry({
                    itemSelector : '.at-gallery-item'
                });
            });
            /*widget*/
            $masonry_boxes.find('.image-gallery-widget').magnificPopup({
                type: 'image',
                gallery: {
                    enabled: true
                }

            });
            $masonry_boxes.find('.single-image-widget').magnificPopup({
                type: 'image'
            });
        });

    });

    function stickyMenu() {

        var scrollTop = at_window.scrollTop();
        var offset = 0;

        if ( scrollTop > offset ) {
            $('#navbar').addClass('navbar-fixed-top');
            $('.sm-up-container').show();
        }
        else {
            $('#navbar').removeClass('navbar-fixed-top');
            $('.sm-up-container').hide();
        }
    }
    //What happen on window scroll
    stickyMenu();
    at_window.on("scroll", function (e) {
        setTimeout(function () {
            stickyMenu();
        }, 300)
    });
});

/*animation with wow*/
wow = new WOW({
        boxClass: 'init-animate',
        animateClass: 'animated' // default
    }
);
wow.init();