<?php
/*adding header options panel*/
$wp_customize->add_panel( 'education-base-header-panel', array(
    'priority'       => 160,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '',
    'title'          => __( 'Header Options', 'education-base' ),
    'description'    => __( 'Customize your awesome site header ', 'education-base' )
) );

/*
* file for header top options
*/
require education_base_file_directory('acmethemes/customizer/header-options/header-top.php');

/*
* file for header logo options
*/
require education_base_file_directory('acmethemes/customizer/header-options/header-logo.php');

/*
* file for social options
*/
require education_base_file_directory('acmethemes/customizer/header-options/social-options.php');

/*adding header image inside this panel*/
$wp_customize->get_section( 'header_image' )->panel = 'education-base-header-panel';
$wp_customize->get_section( 'header_image' )->description = __( 'Applied to header image of inner pages.', 'education-base' );
$wp_customize->remove_control( 'display_header_text' );