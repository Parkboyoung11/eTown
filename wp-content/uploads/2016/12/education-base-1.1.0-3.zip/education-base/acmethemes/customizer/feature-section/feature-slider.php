<?php
/*adding sections for category section in front page*/
$wp_customize->add_section( 'education-base-feature-page', array(
    'priority'       => 10,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '',
    'title'          => __( 'Feature Slider Selection', 'education-base' ),
    'panel'          => 'education-base-feature-panel'
) );

/* feature parent page selection */
$wp_customize->add_setting( 'education_base_theme_options[education-base-feature-page]', array(
    'capability'		=> 'edit_theme_options',
    'default'			=> $defaults['education-base-feature-page'],
    'sanitize_callback' => 'education_base_sanitize_number'
) );
$wp_customize->add_control( 'education_base_theme_options[education-base-feature-page]', array(
    'label'		    => __( 'Select Parent Page for Feature Slider', 'education-base' ),
    'description'   => __( 'Select parent page and its sub-pages will be shown as slides', 'education-base' ),
    'section'       => 'education-base-feature-page',
    'settings'      => 'education_base_theme_options[education-base-feature-page]',
    'type'	  	    => 'dropdown-pages',
    'priority'      => 10
) );

/* number of slider*/
$wp_customize->add_setting( 'education_base_theme_options[education-base-featured-slider-number]', array(
    'capability'		=> 'edit_theme_options',
    'default'			=> $defaults['education-base-featured-slider-number'],
    'sanitize_callback' => 'education_base_sanitize_select'
) );
$choices = education_base_featured_slider_number();
$wp_customize->add_control( 'education_base_theme_options[education-base-featured-slider-number]', array(
    'choices'  	=> $choices,
    'label'		=> __( 'Number Of Slider', 'education-base' ),
    'section'   => 'education-base-feature-page',
    'settings'  => 'education_base_theme_options[education-base-featured-slider-number]',
    'type'	  	=> 'select',
    'priority'  => 20
) );

/*enable animation*/
$wp_customize->add_setting( 'education_base_theme_options[education-base-feature-slider-enable-animation]', array(
    'capability'		=> 'edit_theme_options',
    'default'			=> $defaults['education-base-feature-slider-enable-animation'],
    'sanitize_callback' => 'education_base_sanitize_checkbox'
) );
$wp_customize->add_control( 'education_base_theme_options[education-base-feature-slider-enable-animation]', array(
    'label'		    => __( 'Enable Animation', 'education-base' ),
    'section'       => 'education-base-feature-page',
    'settings'      => 'education_base_theme_options[education-base-feature-slider-enable-animation]',
    'type'	  	    => 'checkbox',
    'priority'      => 125
) );

/*know more text*/
$wp_customize->add_setting( 'education_base_theme_options[education-base-slider-know-more-text]', array(
    'capability'		=> 'edit_theme_options',
    'default'			=> $defaults['education-base-slider-know-more-text'],
    'sanitize_callback' => 'sanitize_text_field'
) );
$wp_customize->add_control( 'education_base_theme_options[education-base-slider-know-more-text]', array(
    'label'		    => __( 'Slider Button Text', 'education-base' ),
    'description'   => __( 'Left empty to disable slider button ', 'education-base' ),
    'section'       => 'education-base-feature-page',
    'settings'      => 'education_base_theme_options[education-base-slider-know-more-text]',
    'type'	  	    => 'text',
    'priority'      => 220
) );